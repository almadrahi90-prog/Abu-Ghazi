package com.abughazi.abughazi

data class RouterConnection(val host:String, val port:Int=8728, val username:String, val password:String, val useTls:Boolean=false)
data class RouterStatus(val identity:String="غير متصل", val uptime:String="--", val cpuLoad:String="--", val freeMemory:String="--")
interface RouterOsClient {
    suspend fun connect(): Result<RouterStatus>
    suspend fun disconnect()
    suspend fun command(path:String, args:Map<String,String> = emptyMap()): Result<List<Map<String,String>>>
}

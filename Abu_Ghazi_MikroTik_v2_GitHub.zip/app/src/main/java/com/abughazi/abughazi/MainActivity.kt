package com.abughazi.abughazi

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.grid.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp

data class MenuItem(val title:String,val icon:String)

class MainActivity:ComponentActivity(){
 override fun onCreate(b:Bundle?){super.onCreate(b);setContent{AbuGhaziApp()}}
}

@Composable fun AbuGhaziApp(){
 var connected by remember{mutableStateOf(false)}
 var show by remember{mutableStateOf(false)}
 var host by remember{mutableStateOf("192.168.1.150")}
 val items=listOf(
  MenuItem("الأجهزة","📡"),MenuItem("المستخدمون","👥"),MenuItem("الكروت","🎫"),
  MenuItem("الباقات","📦"),MenuItem("Hotspot","🌐"),MenuItem("PPPoE","🔑"),
  MenuItem("DHCP","🖧"),MenuItem("IP","🔢"),MenuItem("الواجهات","🔌"),
  MenuItem("Logs","📝"),MenuItem("API Console","⌨️"),MenuItem("التقارير","📊"))
 MaterialTheme{
  Scaffold(topBar={CenterAlignedTopAppBar(title={Text("أبو غازي")},actions={Text(if(connected)"متصل" else "غير متصل",Modifier.padding(12.dp))})}){p->
   Column(Modifier.fillMaxSize().padding(p).padding(16.dp)){
    Card(Modifier.fillMaxWidth()){Column(Modifier.padding(16.dp)){
     Text("إدارة شبكة MikroTik",style=MaterialTheme.typography.titleLarge)
     Spacer(Modifier.height(6.dp)); Text(if(connected)"الراوتر: $host" else "أضف راوتر MikroTik للبدء")
     Spacer(Modifier.height(12.dp)); Button({show=true},Modifier.fillMaxWidth()){Text(if(connected)"إعداد الاتصال" else "اتصال بالراوتر")}
    }}
    Spacer(Modifier.height(16.dp))
    LazyVerticalGrid(columns=GridCells.Fixed(3),verticalArrangement=Arrangement.spacedBy(10.dp),horizontalArrangement=Arrangement.spacedBy(10.dp)){
     items(items){item->Card(Modifier.height(105.dp)){Column(Modifier.fillMaxSize(),horizontalAlignment=Alignment.CenterHorizontally,verticalArrangement=Arrangement.Center){
      Text(item.icon,style=MaterialTheme.typography.headlineSmall);Text(item.title,textAlign=TextAlign.Center)}}}
    }
   }
  }
  if(show) ConnectDialog(host,{show=false},{h->host=h;connected=true;show=false})
 }
}

@Composable fun ConnectDialog(initialHost:String,onDismiss:()->Unit,onConnected:(String)->Unit){
 var host by remember{mutableStateOf(initialHost)};var port by remember{mutableStateOf("8728")}
 var user by remember{mutableStateOf("admin")};var pass by remember{mutableStateOf("")}
 AlertDialog(onDismissRequest=onDismiss,title={Text("الاتصال بـ MikroTik")},text={Column{
  OutlinedTextField(host,{host=it},label={Text("IP أو MikroTik Cloud")})
  OutlinedTextField(port,{port=it},label={Text("API Port")})
  OutlinedTextField(user,{user=it},label={Text("اسم المستخدم")})
  OutlinedTextField(pass,{pass=it},label={Text("كلمة المرور")})
 }},confirmButton={Button({onConnected(host)}){Text("حفظ والاتصال")}},dismissButton={TextButton(onDismiss){Text("إلغاء")}})
}
